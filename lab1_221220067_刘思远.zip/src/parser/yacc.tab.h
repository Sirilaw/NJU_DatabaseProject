/* A Bison parser, made by GNU Bison 3.5.1.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2020 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

#ifndef YY_YY_ROOT_NJU_DBPRACTICE_SRC_PARSER_YACC_TAB_H_INCLUDED
# define YY_YY_ROOT_NJU_DBPRACTICE_SRC_PARSER_YACC_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    EXPLAIN = 258,
    SHOW = 259,
    TABLES = 260,
    CREATE = 261,
    TABLE = 262,
    DROP = 263,
    DESC = 264,
    INSERT = 265,
    INTO = 266,
    VALUES = 267,
    DELETE = 268,
    FROM = 269,
    OPEN = 270,
    DATABASE = 271,
    ON = 272,
    ASC = 273,
    AS = 274,
    ORDER = 275,
    GROUP = 276,
    BY = 277,
    SUM = 278,
    AVG = 279,
    MAX = 280,
    MIN = 281,
    COUNT = 282,
    IN = 283,
    STATIC_CHECKPOINT = 284,
    USING = 285,
    NESTED_LOOP_JOIN = 286,
    SORT_MERGE_JOIN = 287,
    WHERE = 288,
    HAVING = 289,
    UPDATE = 290,
    SET = 291,
    SELECT = 292,
    INT = 293,
    CHAR = 294,
    FLOAT = 295,
    BOOL = 296,
    INDEX = 297,
    AND = 298,
    JOIN = 299,
    INNER = 300,
    OUTER = 301,
    EXIT = 302,
    HELP = 303,
    TXN_BEGIN = 304,
    TXN_COMMIT = 305,
    TXN_ABORT = 306,
    TXN_ROLLBACK = 307,
    ORDER_BY = 308,
    ENABLE_NESTLOOP = 309,
    ENABLE_SORTMERGE = 310,
    STORAGE = 311,
    PAX = 312,
    NARY = 313,
    LIMIT = 314,
    LEQ = 315,
    NEQ = 316,
    GEQ = 317,
    T_EOF = 318,
    IDENTIFIER = 319,
    VALUE_STRING = 320,
    VALUE_INT = 321,
    VALUE_FLOAT = 322,
    VALUE_BOOL = 323
  };
#endif

/* Value type.  */

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



int yyparse (void);

#endif /* !YY_YY_ROOT_NJU_DBPRACTICE_SRC_PARSER_YACC_TAB_H_INCLUDED  */
